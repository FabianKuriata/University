
public class Symbol {
	char symbol;
	String code;
	
	public Symbol(char symbol, StringBuffer code){
		this.code = code.toString();
		this.symbol = symbol;
	}

	
}
