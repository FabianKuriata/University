
public class Main {
	public static void main(String[] args){
		Macierz a = new Macierz(4,4);
		Macierz b = new Macierz(4,4);
		
		a.insertNode(1, 1, 1);
		a.insertNode(1, 3, 1);
		a.insertNode(1, 3, 2);
		a.insertNode(1, 3, 3);
		a.insertNode(2, 2, 4);
		//a.addRandomValues();
		
		b.insertNode(2, 2, 2);
		b.insertNode(-1, 3, 2);
		b.insertNode(2, 1, 3);
		b.insertNode(1, 1, 4);
		b.insertNode(1, 4, 4);
		a.printValues();
		b.printValues();
		
		Macierz.addMatrixes(a, b).printValues();
		
		System.out.println();
	}
}
