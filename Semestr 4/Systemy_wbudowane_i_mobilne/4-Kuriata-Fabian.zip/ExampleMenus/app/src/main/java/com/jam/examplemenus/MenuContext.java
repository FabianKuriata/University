package com.jam.examplemenus;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MenuContext extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_context);
        registerForContextMenu(findViewById(R.id.rabbitImage));
        registerForContextMenu(findViewById(R.id.titleImage));
    }

    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        if(v.getId() == R.id.rabbitImage) {
            menu.setHeaderTitle("Wybierz filtr");
            getMenuInflater().inflate(R.menu.color_menu, menu);
        }
        else if(v.getId() == R.id.titleImage) {
            menu.setHeaderTitle("Wybierz rozmiar tytułu");
            getMenuInflater().inflate(R.menu.size_menu, menu);
        }
    }

    public boolean onContextItemSelected(MenuItem item) {
        ImageView imgv = findViewById(R.id.rabbitImage);
        TextView titleOfImage = findViewById(R.id.titleImage);
        switch(item.getItemId()) {
            case R.id.menu_red:
                imgv.setColorFilter(Color.RED, PorterDuff.Mode.LIGHTEN);
                titleOfImage.setText("Czerwony Królik");
                return true;
            case R.id.menu_blue:
                imgv.setColorFilter(Color.BLUE, PorterDuff.Mode.LIGHTEN);
                titleOfImage.setText("Niebieski Królik");
                return true;
            case R.id.menu_green:
                imgv.setColorFilter(Color.GREEN, PorterDuff.Mode.LIGHTEN);
                titleOfImage.setText("Zielony Królik");
                return true;
            case R.id.menu_clear:
                imgv.setColorFilter(null);
                titleOfImage.setText("Zwykły Królik");
                return true;
            case R.id.size_small:
                titleOfImage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                return true;
            case R.id.size_medium:
                titleOfImage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                return true;
            case R.id.size_large:
                titleOfImage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}

