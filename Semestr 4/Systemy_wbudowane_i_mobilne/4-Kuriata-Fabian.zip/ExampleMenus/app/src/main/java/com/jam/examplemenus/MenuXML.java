package com.jam.examplemenus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MenuXML extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_xml);
    }

    public void basicMenu(View view) {
        Intent intent = new Intent(this, BasicMenu.class);
        startActivity(intent);
    }
    public void contextMenu(View view) {
        Intent intent = new Intent(this, MenuContext.class);
        startActivity(intent);
    }
    public void contextualMenu(View view) {
        Intent intent = new Intent(this, ContextualMenu.class);
        startActivity(intent);
    }
    public void checkableMenu(View view) {
        Intent intent = new Intent(this, Checkable.class);
        startActivity(intent);
    }
}
