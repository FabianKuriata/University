package com.jam.examplemenus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Checkable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkable);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.checkable_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.isChecked()) {
            item.setChecked(false);
        }
        else {
            item.setChecked(true);
        }
        TextView tv1 = findViewById(R.id.first);
        TextView tv2 = findViewById(R.id.second);
        TextView tv3 = findViewById(R.id.third);
        ImageView man = findViewById(R.id.manImage);
        ImageView woman = findViewById(R.id.womanImage);
        ImageView monster = findViewById(R.id.monsterImage);

        switch(item.getItemId()){
            case R.id.checkbox_sub1:
                if(item.isChecked())
                    tv1.setVisibility(View.VISIBLE);
                else
                    tv1.setVisibility(View.INVISIBLE);
                break;
            case R.id.checkbox_sub2:
                if(item.isChecked())
                    tv2.setVisibility(View.VISIBLE);
                else
                    tv2.setVisibility(View.INVISIBLE);
                break;
            case R.id.checkbox_sub3:
                if(item.isChecked())
                    tv3.setVisibility(View.VISIBLE);
                else
                    tv3.setVisibility(View.INVISIBLE);
                break;
            case R.id.radio_sub1:
                man.setVisibility(View.VISIBLE);
                woman.setVisibility(View.INVISIBLE);
                monster.setVisibility(View.INVISIBLE);
                break;
            case R.id.radio_sub2:
                woman.setVisibility(View.VISIBLE);
                man.setVisibility(View.INVISIBLE);
                monster.setVisibility(View.INVISIBLE);
                break;
            case R.id.radio_sub3:
                monster.setVisibility(View.VISIBLE);
                woman.setVisibility(View.INVISIBLE);
                man.setVisibility(View.INVISIBLE);
                break;
        }
        return true;
    }

}
