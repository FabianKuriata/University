package com.jam.examplemenus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ContextualMenu extends AppCompatActivity {

    private ActionMode mActionMode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contextual_menu);

        ImageView imgV = findViewById(R.id.img);
        imgV.setOnLongClickListener(new View.OnLongClickListener(){
            @Override
            public  boolean onLongClick(View v) {
                if(mActionMode != null) {
                    return false;
                }
                mActionMode = startSupportActionMode(mActionModeCallback);
                return true;
            }
        });
    }

    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.contextual_menu, menu);
            mode.setTitle("Wybierz opcje");
            return true;
        }
        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.option1:
                    ImageView img = findViewById(R.id.img);
                    img.setVisibility(View.GONE);
                    Toast.makeText(ContextualMenu.this, "Usunieto", Toast.LENGTH_SHORT).show();
                    mode.finish();
                    return true;
                case R.id.option2:
                    Toast.makeText(ContextualMenu.this, "Udostępnij", Toast.LENGTH_SHORT).show();
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }
    };
}