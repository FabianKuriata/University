package com.jam.examplemenus;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class BasicMenu extends AppCompatActivity {

    int countOfElements = 0;
    //ArrayList<TextView> addedText = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_menu);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.basicMenuLayout);
        TextView textViewExample = findViewById(R.id.textView1);
        EditText editTextExample = findViewById(R.id.editText1);
        switch(item.getItemId()) {
            case R.id.add:
                //count=(TextView)findViewById(R.id.textView);
                TextView tv = new TextView(this);
                countOfElements++;
                tv.setText(Integer.toString(countOfElements));
                tv.setId(countOfElements);
                tv.setGravity(Gravity.CENTER);
                tv.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                linearLayout.addView(tv);
                //count.setText("Dodano element");
                return(true);
            case R.id.reset:
                linearLayout.removeAllViews();
                countOfElements = 0;
                Toast.makeText(this, "Zresetowano", Toast.LENGTH_LONG).show();
                return(true);
            case R.id.basicOption1:
                textViewExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                editTextExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                return(true);
            case R.id.basicOption2:
                textViewExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                editTextExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                return(true);
            case R.id.basicOption3:
                textViewExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
                editTextExample.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
                return true;
            case R.id.subBasicOption1:
                textViewExample.setTextColor(Color.RED);
                editTextExample.setTextColor(Color.RED);
                return true;
            case R.id.subBasicOption2:
                textViewExample.setTextColor(Color.BLUE);
                editTextExample.setTextColor(Color.BLUE);
                return true;
            case R.id.subBasicOption3:
                textViewExample.setTextColor(Color.GREEN);
                editTextExample.setTextColor(Color.GREEN);
                return true;
        }
        return(super.onOptionsItemSelected(item));
    }
}
