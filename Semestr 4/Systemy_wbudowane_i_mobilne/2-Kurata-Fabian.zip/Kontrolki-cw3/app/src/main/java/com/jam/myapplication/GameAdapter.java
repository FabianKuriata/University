package com.jam.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Jam on 23.03.2018.
 */

public class GameAdapter extends BaseAdapter {

    private Context mContext;
    private int[] gamesImages;

    public GameAdapter(Context context, int[] games) {
        this.mContext = context;
        this.gamesImages = games;
    }

    @Override
    public int getCount() {
        return gamesImages.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        final int img = gamesImages[position];
        if(view == null) {
          final LayoutInflater layoutInflater = LayoutInflater.from(mContext);
          view = layoutInflater.inflate(R.layout.grid_game_image, null);
        }

        ImageView gameImage = view.findViewById(R.id.gameItemImg);
        gameImage.setImageResource(img);
        return view;
    }
}
