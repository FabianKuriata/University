package com.jam.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class CustomListView extends AppCompatActivity {

    int[] images = {R.mipmap.far_cry3, R.mipmap.wiedzmin, R.mipmap.rogue_legacy,
                    R.mipmap.ori, R.mipmap.the_walking_dead, R.mipmap.borderlands2,
                    R.mipmap.bioshock2, R.mipmap.fifa18, R.mipmap.gta5};

    String[] listOfGames = new String[] {
      "Far Cry 3", "Wiedźmin 3", "Rogue Legacy", "Ori and the Blind Forest",
            "The Walking Dead", "Borderlands 2", "BioShock 2", "Fifa 18",
            "GTA V"
    };

    String[] descriptions = new String[] {
            "Action, FPS", "RPG", "Platform, Roguelike, Indie", "Platform, Adventure, Indie",
            "Adventure", "FPS", "FPS", "Sport",
            "Action, Adventure"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_view);

        ListView listView = findViewById(R.id.customList);

        GameAdapter gameAdapter = new GameAdapter();

        listView.setAdapter(gameAdapter);
    }

    class GameAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return listOfGames.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = getLayoutInflater().inflate(R.layout.custom_layout, null);

            ImageView imageView = view.findViewById(R.id.imageTitle);
            TextView title = view.findViewById(R.id.title);
            TextView description = view.findViewById(R.id.description);

            imageView.setImageResource(images[i]);
            title.setText(listOfGames[i]);
            description.setText(descriptions[i]);
            return view;
        }
    }
}
