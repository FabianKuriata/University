package com.jam.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        ListView listView = findViewById(R.id.list);

        String[] gameGenre = new String[] {
                "Action", "RPG", "Sport", "JRPG", "Dungeon Crawler",
                "Multiplayer", "Indie", "Platform", "Roguelike",
                "Adventure", "Point&Click", "FPS", "Survival",
                "Fighting"
        };

        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>
                        (this,
                                R.layout.activity_list_item,
                                R.id.listItem, gameGenre);
        listView.setAdapter(arrayAdapter);

    }
}
