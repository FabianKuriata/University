package com.jam.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SavingArea extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving_area);
    }

    public void saveAndLoad(View view) {
        Intent intent = new Intent(this, SaveAndLoad.class);
        startActivity(intent);
    }

    public void sharedPref(View view) {
        Intent intent = new Intent(this, SharedPref.class);
        startActivity(intent);
    }
}
