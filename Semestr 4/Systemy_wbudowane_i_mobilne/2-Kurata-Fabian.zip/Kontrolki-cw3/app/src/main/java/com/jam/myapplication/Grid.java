package com.jam.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

public class Grid extends AppCompatActivity {

    int[] gamesImg = { R.mipmap.far_cry3, R.mipmap.wiedzmin, R.mipmap.rogue_legacy,
            R.mipmap.ori, R.mipmap.the_walking_dead, R.mipmap.borderlands2,
            R.mipmap.bioshock2, R.mipmap.fifa18, R.mipmap.gta5};
    int[] poss = {1, 2, 3, 4};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        GridView gridImageView = findViewById(R.id.gridImageView);

        GameAdapter gameAdapter = new GameAdapter(this, gamesImg);
        gridImageView.setAdapter(gameAdapter);
    }
}
