package com.jam.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class ControlButtons extends AppCompatActivity {

    EditText editText1;
    Button button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_buttons);


        // funcje dla seekbar
        SeekBar sb = findViewById(R.id.seekBar);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            LinearLayout linearLayout = findViewById(R.id.controlsLayout);
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                int progress = seekBar.getProgress();

                ColorDrawable linearColor = (ColorDrawable) linearLayout.getBackground();
                int color = linearColor.getColor();
                int alpha = linearColor.getAlpha();
                int red = Color.red(color);
                int green = Color.green(color);
                int blue = Color.blue(color);
                alpha = 255 - progress;
                linearLayout.setBackgroundColor(Color.argb(alpha, red, green, blue));

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), Integer.toString(seekBar.getProgress()), Toast.LENGTH_SHORT).show();
            }
        });

        // funckje guzika switch
        Switch sButton = findViewById(R.id.switch1);

        sButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            LinearLayout linearLayout = findViewById(R.id.controlsLayout);
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean on) {
                ColorDrawable linearColor = (ColorDrawable) linearLayout.getBackground();
                int color = linearColor.getColor();
                int alpha = linearColor.getAlpha();
                int green = Color.green(color);
                int blue = Color.blue(color);
                int red;
                if(on) {
                    red = 255;
                }
                else {
                    red = 0;
                }

                linearLayout.setBackgroundColor(Color.argb(alpha, red, green, blue));

            }
        });

        // intencja zwrotna - zapamietanie koloru
        editText1=(EditText)findViewById(R.id.messageText);
        button1=(Button)findViewById(R.id.sendBtn);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = editText1.getText().toString();
                Intent intent = new Intent();
                intent.putExtra("MESSAGE",message);
                setResult(2,intent);
                onBackPressed();//finishing activity

            }
        });

    }

    public void onToggleClicked(View view) {
        boolean btnChecked = ((ToggleButton)view).isChecked();

        Switch sw = findViewById(R.id.switch1);
        SeekBar sb = findViewById(R.id.seekBar);
        TextView tv = findViewById(R.id.changeBrightness);
        if(btnChecked) {
            sw.setVisibility(View.VISIBLE);
            sb.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
        }
        else {
            sw.setVisibility(View.INVISIBLE);
            sb.setVisibility(View.INVISIBLE);
            tv.setVisibility(View.INVISIBLE);
        }
    }


}
