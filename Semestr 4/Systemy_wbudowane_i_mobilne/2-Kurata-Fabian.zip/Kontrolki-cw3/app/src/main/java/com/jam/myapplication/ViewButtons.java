package com.jam.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class ViewButtons extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_buttons);

        Spinner spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this,
                        android.R.layout.simple_spinner_dropdown_item,
                        gameGenre);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int index = adapterView.getSelectedItemPosition();

                Toast.makeText(getApplicationContext(),
                        "Wybrałeś grę typu: " + gameGenre[index],
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    String[] gameGenre = new String[] {
            "Action", "RPG", "Sport", "JRPG", "Dungeon Crawler",
            "Multiplayer", "Indie", "Platform", "Roguelike",
            "Adventure", "Point&Click", "FPS", "Survival",
            "Fighting"
    };




    public void listView(View view) {
        Intent intent = new Intent(this, ListViewActivity.class);
        startActivity(intent);
    }

    public void customList(View view) {
        Intent intent = new Intent(this, CustomListView.class);
        startActivity(intent);
    }

    public void gridImages(View view) {
        Intent intent = new Intent(this, Grid.class);
        startActivity(intent);
    }
}
