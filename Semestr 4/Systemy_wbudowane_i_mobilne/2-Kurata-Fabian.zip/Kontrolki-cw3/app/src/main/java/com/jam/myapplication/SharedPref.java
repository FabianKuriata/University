package com.jam.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SharedPref extends AppCompatActivity {
    EditText ed1, ed2, ed3;
    Button b1;

    public static final String Pref = "Prefs";
    public static final String Email = "name";
    public static final String Subject = "surname";
    public static final String Body = "email";

    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_pref);

        ed1 = findViewById(R.id.mailEdit);
        ed2 = findViewById(R.id.subjectEdit);
        ed3 = findViewById(R.id.bodyEdit);

        b1 = findViewById(R.id.saveBtn);
        sharedpreferences = getSharedPreferences(Pref, Context.MODE_PRIVATE);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String e = ed1.getText().toString();
                String sub = ed2.getText().toString();
                String b = ed3.getText().toString();

                SharedPreferences.Editor editor = sharedpreferences.edit();

                editor.putString(Email, e);
                editor.putString(Subject, sub);
                editor.putString(Body, b);
                editor.commit();
                Toast.makeText(getApplicationContext(), "Zapisano", Toast.LENGTH_SHORT).show();
            }
        });

        ed1.setText(sharedpreferences.getString(Email, null));
        ed2.setText(sharedpreferences.getString(Subject, null));
        ed3.setText(sharedpreferences.getString(Body, null));

    }

    public void sendEmail(View view) {
        EditText mail = findViewById(R.id.mailEdit);
        EditText subject = findViewById(R.id.subjectEdit);
        EditText body = findViewById(R.id.bodyEdit);
        String sMail = mail.getText().toString();
        String sSubject = subject.getText().toString();
        String sBody = body.getText().toString();

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto", sMail, null));
        //emailIntent.setType("text/plain");
        //emailIntent.putExtra(Intent.EXTRA_EMAIL, "jan@pl.com");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, sSubject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, sBody);
        startActivity(Intent.createChooser(emailIntent, "Wyślij maila"));
    }

}
