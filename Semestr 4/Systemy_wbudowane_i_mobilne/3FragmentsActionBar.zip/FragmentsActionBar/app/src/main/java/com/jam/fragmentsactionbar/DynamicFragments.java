package com.jam.fragmentsactionbar;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class DynamicFragments extends AppCompatActivity implements OnWyborOpcjiListener{
    private static final String TAG_F11 = "Fragment11";
    private static final String TAG_F12 = "Fragment12";

    Fragment11 f11;
    Fragment12 f12;
    FragmentTransaction transakcja;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_fragments);

        if(savedInstanceState == null) {
            f11 = new Fragment11();
            f12 = new Fragment12();

            transakcja = getSupportFragmentManager().beginTransaction();
            transakcja.add(R.id.kontener, f11, TAG_F11);
            transakcja.detach(f11);
            transakcja.add(R.id.kontener, f12, TAG_F12);
            transakcja.detach(f12);
            transakcja.commit();
        }
        else {
            f11 = (Fragment11) getSupportFragmentManager()
                    .findFragmentByTag(TAG_F11);
            f12 = (Fragment12) getSupportFragmentManager()
                    .findFragmentByTag(TAG_F12);
        }
    }

    @Override
    public void onWyborOpcji(int opcja) {
        FragmentTransaction transakcja =
                getSupportFragmentManager().beginTransaction();


        switch(opcja) {
            case 1:
                Toast.makeText(getApplicationContext(),"Opcja 1", Toast.LENGTH_SHORT).show();
                transakcja.detach(f12);
                transakcja.attach(f11);
                break;
            case 2:
                Toast.makeText(getApplicationContext(),"Opcja 2", Toast.LENGTH_SHORT).show();
                transakcja.detach(f11);
                transakcja.attach(f12);
                break;
        }
        transakcja.commit();
    }
}
