package com.jam.fragmentsactionbar;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class StaticFrag extends Fragment implements View.OnClickListener {


    public StaticFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        final View v = inflater.inflate(R.layout.fragment_static, container, false);

        Button plus = v.findViewById(R.id.plusSize);
        Button minus = v.findViewById(R.id.minusSize);
        plus.setOnClickListener(this);
        minus.setOnClickListener(this);
        return v;
    }


    @Override
    public void onClick(View view) {
        TextView tv = getView().findViewById(R.id.settings);

        //tv.setText("bobobb");
        //Toast.makeText(view.getContext(), Float.toString(size), Toast.LENGTH_SHORT).show();
        switch(view.getId()) {
            case R.id.plusSize: {
                float size = tv.getTextSize();
                size += 1;
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
                Toast.makeText(view.getContext(), Float.toString(size), Toast.LENGTH_SHORT).show();
                break;
            }
            case R.id.minusSize: {
                float size = tv.getTextSize();
                size -= 1;
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
                Toast.makeText(getContext(), Float.toString(size), Toast.LENGTH_SHORT).show();
                break;
            }
        }
    }
}
