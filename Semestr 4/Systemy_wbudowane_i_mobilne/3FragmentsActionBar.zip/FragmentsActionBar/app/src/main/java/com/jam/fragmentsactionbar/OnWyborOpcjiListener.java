package com.jam.fragmentsactionbar;

public interface OnWyborOpcjiListener {
    public void onWyborOpcji(int opcja);
}
