package com.jam.organizer3000;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void launchTodoList(View view) {
        final Intent intent = new Intent(this, TodoList.class);
        startActivity(intent);
    }

    public void launchNotepad(View view) {
        final Intent intent = new Intent(this, Note.class);
        startActivity(intent);
    }

    public void launchFeedback(View view) {
        final Intent intent = new Intent(this, Feedback.class);
        startActivity(intent);
    }

    public void finishApp(View view) {
        finish();
    }
}
