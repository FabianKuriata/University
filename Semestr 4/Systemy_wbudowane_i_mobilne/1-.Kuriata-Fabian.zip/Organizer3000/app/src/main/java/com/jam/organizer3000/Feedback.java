package com.jam.organizer3000;

import android.app.Activity;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

public class Feedback extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        View feedbackWindow = (View) findViewById(R.id.feedback_layout);
        feedbackWindow.setOnLongClickListener(new View.OnLongClickListener(){
            public boolean onLongClick(View v) {
                finish();
                return true;
            }
        });
    }

    public void submit(View view){
        RadioButton rb = (RadioButton) findViewById(R.id.radioButton2);
        ConstraintLayout cl = (ConstraintLayout) findViewById(R.id.feedback_layout);

        ConstraintSet c = new ConstraintSet();
        if(rb.isChecked()){
            Toast.makeText(this,
                    "Pozdrów znajomego!",
                    Toast.LENGTH_SHORT).show();
            ImageView iv = (ImageView) findViewById(R.id.imageView);
            //iv.setImageResource(R.mipmap.blue_smiley_face);
            iv.setVisibility(View.VISIBLE);

        }
        else {
            Toast.makeText(this,
                    "Szkoda, że nie polecisz :(",
                    Toast.LENGTH_SHORT).show();
            ImageView iv = (ImageView) findViewById(R.id.imageView);
            iv.setImageResource(R.mipmap.sad_face);
            iv.setVisibility(View.VISIBLE);

        }

        onBackPressed();
    }
}
