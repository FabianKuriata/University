package com.jam.organizer3000;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class TodoList extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);


        ImageButton addButton = (ImageButton) findViewById(R.id.addButton); // przypisanie przycisku do dodawania zadan

        final Context context = this;
        addButton.setOnClickListener(new View.OnClickListener(){
            int i = 0;

            public void onClick(View view) {
                LinearLayout ll = (LinearLayout) findViewById(R.id.listOfTask);
                EditText et = (EditText) findViewById(R.id.editText);

                // utworzenie nowego tekstu wraz ze zmiana parametrow
                TextView tv = new TextView(context);
                tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                tv.setText(et.getText().toString());
                tv.setTextSize(20);
                tv.setPadding(40,20,40,20);
                tv.setId(i);

                // wyczyszczenie pola do dodawania zadan
                et.setText("");

                // dodanie zadania
                ll.addView(tv);
                i++;
                Toast.makeText(context,
                        "Dodano nowe zadanie",
                        Toast.LENGTH_SHORT).show();
        }

        });

    }

}
