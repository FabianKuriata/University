package com.jam.organizer3000;


import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.RelativeLayout;
import android.widget.ToggleButton;

public class Note extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        //RelativeLayout rl = findViewById(R.id.notepadWindow);
        Button backButton = (Button) findViewById(R.id.callback);
        final Button noteButton = (Button) findViewById(R.id.menuButton);
        final String name = "Zeszyt";
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeName(name);
            }
        });


    }

    public void changeName(String name){
        Intent intent = new Intent(this, Menu.class);
        intent.putExtra("Name", name);
        startActivity(intent);
    }

    public void goBack(View view){
        onBackPressed();
    }



    public void makeDark(View view) {
        boolean isTurnOn = ((ToggleButton) view).isChecked();
        RelativeLayout rl = findViewById(R.id.notepadWindow);
        GridLayout gl = findViewById(R.id.menuLayout);
        EditText et = findViewById(R.id.note);

        if(isTurnOn){
            rl.setBackgroundColor(Color.parseColor("#606060"));
            et.setTextColor(Color.parseColor("#FFFFFF"));

            //gl.setBackgroundColor(Color.parseColor("#606060"));
            //et.setTextColor(Color.parseColor("#FFFFFF"));
        }
        else {
            rl.setBackgroundColor(Color.parseColor("#FFFFFF"));
            //gl.setBackgroundColor(Color.parseColor("#FFFFFF"));
            et.setTextColor(Color.parseColor("#000000"));
        }
    }
}
