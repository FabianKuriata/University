import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class Deck {
	ArrayList<Card> deck = new ArrayList<Card>();
	Card card;
	int backsides = 0;
	int frontsides = 0;
	boolean end = false;
	
	public Deck(){
		while(!end){
			create();
			
			if(card.value == 0){
				end = true;
			}
			else{
				deck.add(card);
			}
			
			if(deck.size()>=1){
				set();
			}
					
		}
		System.out.println("Utworzono talie "+deck.size()+" kart");
	}
	
	private void create(){
		card = new Card();
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void set() {
		Collections.sort(deck, new Comparator() {

	        public int compare(Object o1, Object o2) {

	            Integer val1 = ((Card) o1).value;
	            Integer val2 = ((Card) o2).value;
	            int sComp = val1.compareTo(val2);

	            if (sComp != 0) {
	               return sComp;
	            } else {
	               Integer col1 = ((Card) o1).color;
	               Integer col2 = ((Card) o2).color;
	               return col1.compareTo(col2);
	            }
	    }});
	}
	
	public void display(){
		
		for(Card temp: deck){
			System.out.println(temp);
		}
	}
	
	public void amount(){
		System.out.println("Liczba kart: "+deck.size());
	}
	
	public void displayV(int v){
		Iterator<Card> itr = deck.iterator();
		while(itr.hasNext()){
			Card temp = itr.next();
			if(temp.getValue() == v)
				System.out.println(temp);
		}
	}
	
	public void displayC(int c){
		Iterator<Card> itr = deck.iterator();
		
		for(;itr.hasNext();){
			Card temp = itr.next();
			if(temp.getColor() == c)
				System.out.println(temp);
		}
	}
	
	public void count(){
		Iterator<Card> itr = deck.iterator();
		while(itr.hasNext()){
			Card temp = itr.next();
			if(temp.hidden == true){
				backsides++;
			}
			else
				frontsides++;
		}
	}
	
	public void delete(int v){
		Iterator<Card> itr = deck.iterator();
		
		while(itr.hasNext()){
			Card temp;
			temp = itr.next();
			if(temp.value == v){
				itr.remove();
				System.out.println("Usunieto: "+ temp);
			}
		}
	}
}
