

#include "wektor_rzadki.h"

using namespace std;


int const VECTOR_LENGTH_DEFAULT = 100;
int const OFFSETS_VALUES_LENGTH_DEFAULT = 5;

int main() {
	bool working = true;
	//int vectorRare[VECTOR_LENGTH_DEFAULT];
	int defaultValue = 0;
	int vectorLength = VECTOR_LENGTH_DEFAULT;
	int offValLength = OFFSETS_VALUES_LENGTH_DEFAULT;
	//for (int i = 0; i < VECTOR_LENGTH_DEFAULT; i++) {
	//	vectorRare[i] = defaultValue;
	//}
	int *offsets = new int[offValLength];
	int *values = new int[offValLength];
	int occupiedOffsets = 0;

	while (working) {
		
		working = consoleInterface(defaultValue, vectorLength, offsets, values, offValLength, occupiedOffsets);		
		
	}
	return 0;
}




