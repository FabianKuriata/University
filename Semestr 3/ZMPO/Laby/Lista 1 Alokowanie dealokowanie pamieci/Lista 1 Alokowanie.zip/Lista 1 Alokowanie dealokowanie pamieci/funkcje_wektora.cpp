#include "funkcje_wektora.h"
#include "wektor_rzadki.h"
using namespace std;

void mvec(int length, int value, int &vectorLength, int &defaultValue) {

	vectorLength = length;
	defaultValue = value;
	cout << "Utworzono wektor o dlugosci " + to_string(vectorLength) + " i wartosci domyslnej " + to_string(defaultValue) << endl;
	//*vectorRare = 10;
	//cout << *vectorRare;
};

void len(int newLength, int &vectorLength) {

	vectorLength = newLength; // TODO usuwanie

}

void def(int offset, int value, int *offsets, int *values, int &offValLength, int &occupiedOffsets, int &defaultValue) {
	
	if (value != defaultValue ) {
		if (occupiedOffsets >= offValLength) {
			// realokacja
		}
		else {
			
			bool isOffsetExist = false;
		 
			//for (int i = 0; i < occupiedOffsets; i++) {
			//	if (*offsets == offset) {
			//		isOffsetExist = true;
			//		*offsets = *values;
			//		offsets -= i;
			//		values -= i;
			//		i = occupiedOffsets;
			//	}
			//	offsets++;
			//	values++;
			//}

			if (!isOffsetExist) {
				offsets += occupiedOffsets;
				values += occupiedOffsets;
				*offsets = offset;
				*values = value;
				occupiedOffsets++;

				int j, tempOff, tempVal;

				for (int i = 0; i < occupiedOffsets; i++) {
					j = i;

					while (j > 0 && *offsets < *(offsets - 1)) {
						tempOff = *offsets;
						tempVal = *values;
						*offsets = *(offsets - 1);
						*values = *(values - 1);
						*(offsets - 1) = tempOff;
						*(values - 1) = tempVal;

						j--;
						offsets--;
						values--;
					}
				}
			}
			
		}
		
		//// TODO SORTOWANIE
		
		
		cout << "Dodano " + to_string(value) + " na pozycje " + to_string(offset) + "  " << occupiedOffsets << " " << offValLength << endl;
	}
	else {
		cout << "Podana wartosc jest wartoscia domyslna" << endl;
	}

}

void print(int vectorLength, int defaultValue, int *offsets, int *values, int &occupiedOffsets) {

	bool isOffset = false;

	cout << "len: " + to_string(vectorLength) + " values: ";
	
	for (int i = 0; i < vectorLength; i++) {
		if (i == *offsets) {
			cout << *values;
			offsets++;
			values++;
		}
		else {
			cout << defaultValue;
		}

		if (i < vectorLength - 1) {
			cout << ", ";
		}
	}
}