#pragma once

#include "interfejs.h"
#include "wektor_rzadki.h"
#include "funkcje_wektora.cpp"

void mvec(int length, int value, int &vectorLength, int &defaultValue);
void len(int newLength, int &vectorLength);
void def(int offset, int value, int *offsets, int *values, int &offValLength, int &occupiedOffsets, int &defaultValue);
void print(int vectorLength, int defaultValue, int *offsets, int *values, int *occupiedOffsets);